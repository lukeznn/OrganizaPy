import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import main


class OrganizaPyTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.data_path = Path(self.temp_dir.name) / "tarefas.json"
        self.patcher = patch.object(main, "DATA_FILE", self.data_path)
        self.patcher.start()

    def tearDown(self):
        self.patcher.stop()
        self.temp_dir.cleanup()

    def test_adicionar_tarefa(self):
        main.adicionar_tarefa("Estudar Python", "alta")
        tarefas = main.carregar_tarefas()
        self.assertEqual(len(tarefas), 1)
        self.assertEqual(tarefas[0]["titulo"], "Estudar Python")
        self.assertEqual(tarefas[0]["prioridade"], "alta")
        self.assertFalse(tarefas[0]["concluida"])

    def test_concluir_tarefa(self):
        main.adicionar_tarefa("Fazer atividade", "media")
        main.concluir_tarefa(1)
        self.assertTrue(main.carregar_tarefas()[0]["concluida"])

    def test_remover_tarefa(self):
        main.adicionar_tarefa("Tarefa temporária", "baixa")
        main.remover_tarefa(1)
        self.assertEqual(main.carregar_tarefas(), [])

    def test_id_incrementa(self):
        main.adicionar_tarefa("Primeira", "baixa")
        main.adicionar_tarefa("Segunda", "alta")
        ids = [t["id"] for t in main.carregar_tarefas()]
        self.assertEqual(ids, [1, 2])


if __name__ == "__main__":
    unittest.main()
